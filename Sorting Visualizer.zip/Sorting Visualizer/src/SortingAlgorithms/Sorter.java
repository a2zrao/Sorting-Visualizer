package SortingAlgorithms;

import GUI.SortVisualizer;




public abstract class Sorter
{
    public abstract void sort(SortVisualizer array);
    public abstract String toString();
    public abstract long getDelay();
}